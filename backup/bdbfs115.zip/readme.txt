
		     Multi-format DBF-Editor BDBFS.
		     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	The BDBFS is the powerful editor of DBF-files. It has
 easy-to-use interface, supports the basic formats of DBF-s
 databases, memos and indexes (Clipper,FoxPro,dBase4,SIX) and can 
 execute a lot of operations with databases.

	To install BDBFS you should place BDBFS.EXE & BDBFS.HLP
 somewhere in PATH.

	Usage:  Bdbfs <file.dbf> or
		Bdbfs <mask> (f.e. *.dbf)

	You can use additional parameters. See BDBFS.TXT.

	You can use bdbfs.reg to install BDBFS as default WINDOWS 
 DBF-Editor.

	The Bdbfs was linked in protected mode, so you can't use 286-s.

	BDBFS is shareware. See register.frm for details.
	BDBFS can be freely distributed.

	Thank you for trying BDBFS.


Yevgen Bondar
elb@umh0.bank.gov.ua
http://www.geocities.com/Bondar_Eugen
