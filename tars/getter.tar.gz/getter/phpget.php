<?php
if ($argv[1] == "") { die("Uso: php $argv[0] http://\n ej: php $argv[0] http://www.google.com/search?q=mg.php\n"); }
echo file_get_contents($argv[1]."\n\n");
?>
